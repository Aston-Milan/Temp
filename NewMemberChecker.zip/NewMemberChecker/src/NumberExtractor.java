import java.io.*;
import java.util.*;


public class NumberExtractor {

    public static void main(String[] args) {
        String inputFile = "input.txt"; // File to read words from
        String comparisonFile = "comparison.txt"; // File with numbers to compare
        String outputFileUnique = "unique_numbers.txt"; // File to save unique numbers
        String outputFileAll = "all_numbers.txt"; // File to save all extracted numbers

        Set<String> extractedNumbers = new HashSet<>();
        Set<String> comparisonNumbers = new HashSet<>();
        
        // Step 1: Read data from the input file and extract numbers
        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] words = line.split("\\s+"); // Split by whitespace
                for (String word : words) {
                    if (isNumeric(word)) {
                        extractedNumbers.add(word); // Only add if the word is numeric
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Step 2: Read numbers from the comparison file
        try (BufferedReader br = new BufferedReader(new FileReader(comparisonFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] words = line.split("\\s+");
                Collections.addAll(comparisonNumbers, words);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Step 3: Find numbers that are different from the comparison file
        Set<String> uniqueNumbers = new HashSet<>(extractedNumbers);
        uniqueNumbers.removeAll(comparisonNumbers); // Remove all that are in comparison

        // Step 4: Save unique numbers and all numbers to files
        try (PrintWriter allNumbersWriter = new PrintWriter(new FileWriter(outputFileAll));
             PrintWriter uniqueNumbersWriter = new PrintWriter(new FileWriter(outputFileUnique))) {
             
            // Save all extracted numbers
            for (String number : extractedNumbers) {
                allNumbersWriter.println(number);
            }

            // Save unique numbers
            for (String number : uniqueNumbers) {
                uniqueNumbersWriter.println(number);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Processing complete. Unique numbers and all numbers saved to files.");
    }

    // Helper method to check if a string is numeric
    private static boolean isNumeric(String str) {
        return str != null && str.matches("\\d+"); // Matches only digits
    }
}
