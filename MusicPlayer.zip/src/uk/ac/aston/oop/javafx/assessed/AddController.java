package uk.ac.aston.oop.javafx.assessed;

import javafx.beans.binding.Bindings;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import uk.ac.aston.oop.javafx.assessed.model.CD;

public class AddController {
	
	boolean owned;
	static CD cd;
	static boolean finalConfirmation = false;

	@FXML
	TextField enterTitle;
	@FXML
	TextField enterArtist;
	@FXML
	Label playTimeLable;
	@FXML
	Slider playTimeSlider;
	@FXML
	Label numTracksLabel;
	@FXML
	Slider numTracksSlider;
	
    @FXML
    public void initialize() {
        playTimeLable.textProperty().bind(Bindings.createStringBinding(() -> "Playing time: " + (int)playTimeSlider.getValue(), playTimeSlider.valueProperty()));
        numTracksLabel.textProperty().bind(Bindings.createStringBinding(() -> "Number of tracks: " + (int)numTracksSlider.getValue(), numTracksSlider.valueProperty()));
    }

	
	@FXML
	public void ownSelected() {
		owned = !owned;
		System.out.println(owned);
	}

	@FXML
	public void create() {
		String title = enterTitle.getText();
		String artist = enterArtist.getText();
		int tracks = (int) numTracksSlider.getValue();
		int time = (int) playTimeSlider.getValue();
		final CD cd2 = new CD(title, artist, tracks, time);
		if(owned) {
			cd2.setOwn(true);
		}
		
		cd = cd2;
		finalConfirmation = true;
		playTimeLable.getScene().getWindow().hide();

	}
	@FXML
	public void cancel() {
		playTimeLable.getScene().getWindow().hide();
	}
	
	
}
