import java.util.HashMap;

public class PhoneMap {
    private HashMap<String, Phone> phoneMap;

    public PhoneMap() {
        phoneMap = new HashMap<>();
    }

    public void addPhone(Phone phone) {
        String key = phone.getBrand() + phone.getModel();
        phoneMap.put(key, phone);
    }

    public String toString() {
        StringBuilder result = new StringBuilder();
        for (String key : phoneMap.keySet()) {
            Phone phone = phoneMap.get(key);
            result.append(phone.toString()).append("\n");
        }
        return result.toString();
    }

    public Phone search(String brand, String model) {
        String key = brand + model;
        return phoneMap.get(key);
    }
}
