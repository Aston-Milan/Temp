import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


@SuppressWarnings("unused")
public class PhoneMain {
	PhoneList phoneList = new PhoneList();
	  public static void main(String[] args) {
		  Scanner in;
		  PhoneList phoneList = new PhoneList();
		  
		  
		  String filename;
		  filename = "/Users/panmi/eclipse-workspace/Week10Project/phoneData.csv/";
			    try {
			      
				File file = new File(filename);
			      in = new Scanner(file);
			      System.out.println("Loaded File Successfully");

			      in.nextLine();
			    while (in.hasNextLine()) {
			        String[] data = in.nextLine().split(",");
			        Phone phone = new Phone(data[0]); // Brand name 
			        phone.setModel(data[1]);
			        phone.setAnnounced(data[8]);
			        phone.setWeight_g(Float.parseFloat(data[11]));
			        //System.out.println(data[11]);
			        phone.setInternal_memory(data[21]);
			        phone.setApprox_price_EUR(Integer.parseInt(data[36]));
			        phoneList.addPhone(phone);			        
}
			    System.out.println("Size of PhoneList: " + phoneList.getSize());
			    //System.out.println(phoneList.toString());
			    phoneList.sort();
			    //System.out.println("PhoneList after sorting:");
			    //System.out.println(phoneList.toString());
			    Phone searchedPhone = phoneList.search("Apple", "iPhone 7 Plus");
			    System.out.println("\nSearched Phone:\n" + searchedPhone);
			    PhoneList expensivePhones = phoneList.searchByPrice(600);
			    System.out.println("\nPhones with price greater than 600 Euros:\n" + expensivePhones.toString());
			    //System.out.println("Size of PhoneList: " + phoneList.getSize());
			    PhoneList priceRangePhones = phoneList.findPhonesInPriceRange(600, 700);
			    System.out.println("\nPhones with prices between 600 and 700 Euros:\n" + priceRangePhones.toString());
		        Scanner scanner = new Scanner(System.in);
		        System.out.print("Enter a lower price bound: ");
		        int lowerBound = scanner.nextInt();

		        System.out.print("Enter an upper price bound: ");
		        int upperBound = scanner.nextInt();

		        //System.out.println("You entered lower bound: " + lowerBound);
		        //System.out.println("You entered upper bound: " + upperBound);
		        PhoneList priceRangePhones1 = phoneList.findPhonesInPriceRange(lowerBound, upperBound);
		        System.out.println("\nPhones with prices between " + lowerBound + " and " + upperBound + " Euros:\n" + priceRangePhones1.toString());
		        scanner.close();
			    
			    } catch (FileNotFoundException e) {
				      e.printStackTrace();
				    }  
	 }
}
	  
	  