import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PhoneList {
  private List<Phone> phones;

  public PhoneList(List<Phone> phones) {
    this.phones = phones;
  }


  public PhoneList() {
    this.phones = new ArrayList<>(); // Initialize the list
  }

  public void addPhone(Phone phone) {
    phones.add(phone);
  }

  public int getSize() {
    return phones.size();
  }

  public void sort() {
    Collections.sort(phones);
  }

  @Override
    public String toString() {
    StringBuilder result = new StringBuilder();
    for (Phone phone : phones) {
      result.append(phone.toString()).append("\n");
    }
    return result.toString();
  }

  public Phone search(String brand, String model) {
    for (Phone phone : phones) {
      if (phone.getBrand().equals(brand) && phone.getModel().equals(model)) {
        return phone;
      }
    }
    return null;
  }

  public PhoneList searchByPrice(int minPrice) {
    PhoneList result = new PhoneList();
    for (Phone phone : phones) {
      if (phone.getApprox_price_EUR() > minPrice) {
        result.addPhone(phone);
      }
    }
    return result;
  }
  
  public PhoneList findPhonesInPriceRange(int minPrice, int maxPrice) {
	   PhoneList result = new PhoneList();
	    for (Phone phone : phones) {
	      if ((phone.getApprox_price_EUR() > minPrice) && (phone.getApprox_price_EUR() < maxPrice)) {
	        result.addPhone(phone);
	      }
	    }
	    return result;
	  
	  
  }
  }

