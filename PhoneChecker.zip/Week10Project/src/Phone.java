import java.util.Comparator;

@SuppressWarnings("unused")
public class Phone implements Comparable<Phone> {
  private String brand;
  private String model;
  private String announced;
  private float weight_g;
  private String internal_memory;
  private int approx_price_EUR;

  public Phone(String brand) {
    this.brand = brand;
  }

  public String getBrand() {
    return brand;
  }

  public String getModel() {
    return model;
  }

  public void setModel(String model) {
    this.model = model;
  }

  public String getAnnounced() {
    return announced;
  }

  public void setAnnounced(String announced) {
    this.announced = announced;
  }

  public float getWeight_g() {
    return weight_g;
  }

  public void setWeight_g(float weight_g) {
    this.weight_g = weight_g;
  }

  public String getInternal_memory() {
    return internal_memory;
  }

  public void setInternal_memory(String internal_memory) {
    this.internal_memory = internal_memory;
  }

  public int getApprox_price_EUR() {
    return approx_price_EUR;
  }

  public void setApprox_price_EUR(int approx_price_EUR) {
    this.approx_price_EUR = approx_price_EUR;
  }

  @Override
    public String toString() {
    return brand + ", " + model + ", " + announced + ", " + weight_g + ", " +
      internal_memory + ", " + approx_price_EUR + " euros";
  }

  @Override
    public int compareTo(Phone otherPhone) {
    return Integer.compare(this.approx_price_EUR, otherPhone.approx_price_EUR);
  }
}
