package object;

import javax.imageio.ImageIO;

import main.GamePanel;

public class ObjectChest extends SuperObject{
	GamePanel gp;

	
	public ObjectChest(GamePanel gp) {
		
		name = "Chest";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/chest.png"));
			uTool.ScaleImages(image, gp.tileSize, gp.tileSize);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}