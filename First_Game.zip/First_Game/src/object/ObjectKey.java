package object;

import javax.imageio.ImageIO;
import main.GamePanel;

public class ObjectKey extends SuperObject{
	
	GamePanel gp;
	
	public ObjectKey(GamePanel gp) {
		
		name = "Key";
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/objects/key.png"));
			uTool.ScaleImages(image, gp.tileSize, gp.tileSize);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
