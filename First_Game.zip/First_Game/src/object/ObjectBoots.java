package object;

import javax.imageio.ImageIO;

import main.GamePanel;

public class ObjectBoots extends SuperObject{
	
	GamePanel gp;
	
	public ObjectBoots(GamePanel gp) {
		
		name = "Boots";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/boots.png"));
			uTool.ScaleImages(image, gp.tileSize, gp.tileSize);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
