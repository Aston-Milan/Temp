package object;

import javax.imageio.ImageIO;

import main.GamePanel;

public class ObjectDoor extends SuperObject{
	
	GamePanel gp;

	
	public ObjectDoor(GamePanel gp) {
		
		
		name = "Door";
		try {
			image = ImageIO.read(getClass().getResourceAsStream("/objects/door.png"));
			uTool.ScaleImages(image, gp.tileSize, gp.tileSize);
		} catch (Exception e) {
			// TODO: handle exception
		}
		collision = true;
	}
}
