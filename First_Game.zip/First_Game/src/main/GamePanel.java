package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

import entity.Player;
import object.SuperObject;
import tile.TileManager;

public class GamePanel extends JPanel implements Runnable {

	// SCREEN SETTINGS
	// final means it cannot be changed later on, EG: if I added scale = 5 at some
	// point later, it would throw an error
	public final int originalTileSize = 16; // 16 x 16 size
	public final int scale = 3;
	public final int tileSize = originalTileSize * scale; // 48 x 48 tiles
	public final int maxScreenCol = 16;
	public final int maxScreenRow = 12;
	public final int screenWidth = tileSize * maxScreenCol; // 768p
	public final int screenHeight = tileSize * maxScreenRow; // 576p
	
	public final int maxWorldCol = 50;
	public final int maxWorldRow = 50;

	int fps = 60;
	
	TileManager tileM = new TileManager(this);

	KeyHandler keyH = new KeyHandler();
	public CollisionChecker cChecker = new CollisionChecker(this);
	public Player player = new Player(this, keyH);
	
	public SuperObject obj[] = new SuperObject[10];
	public AssetSetter aSetter = new AssetSetter(this);
	
	public UI ui = new UI(this);
	
	Sound soundEffect = new Sound();
	Sound music = new Sound();
	
	
	Thread gameThread;

	// set player defaults
	int playerX = 100;
	int playerY = 100;
	int playerSpeed = 4;

	public GamePanel() {

		this.setPreferredSize(new Dimension(screenWidth, screenHeight)); // sets the size of this class (JPanel)
		this.setBackground(Color.black);
		this.setDoubleBuffered(true);
		this.addKeyListener(keyH);
		this.setFocusable(true);

	}
	
	public void setupGame() {
		
		aSetter.setObject();
		playMusic(0);
	}

	public void startGameThread() {

		gameThread = new Thread(this);
		gameThread.start();

	}

	public void run() {

		double drawInterval = 1000000000 / fps;
		double nextDrawTime = System.nanoTime() + drawInterval;

		while (gameThread != null) {

			update();
			repaint();



			try {
				double remainingTime = nextDrawTime - System.nanoTime();
				remainingTime = remainingTime / 1000000;

				if (remainingTime < 0) {
					remainingTime = 0;
				}

				Thread.sleep((long) remainingTime);

				nextDrawTime += drawInterval;

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void update() {
		player.update();

	}

	// this draws the stuff
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		// Debug
		long drawStart = 0;
		if(keyH.checkDrawTime == true) {
		drawStart = System.nanoTime();
		}
		

		tileM.draw(g2);
		
		for(int i = 0;i < obj.length;i++) {
			if(obj[i] != null) {
				obj[i].draw(g2, this);
			}
		}
		
		player.draw(g2);

		
		
		
		ui.draw(g2);
		
		// Debug
		
		if(keyH.checkDrawTime == true) {
		long drawEnd = System.nanoTime();
		long passed = drawEnd - drawStart;
		g2.setColor(Color.white);
		g2.drawString("Draw Time: " + passed, 10, 400);
		System.out.println("Draw Time: " + passed);
		}
		
		
		g2.dispose();

	}
	
	
	
	public void playMusic(int i) {
		
		music.setFile(i);
		music.play();
		music.loop();
	}
	
	public void stopMusic() {
		
		soundEffect.stop();
	}

	public void playSoundEffect(int i) {
		
		soundEffect.setFile(i);
		soundEffect.play();
		
	}
}
