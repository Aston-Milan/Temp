package entity;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.KeyHandler;
import main.UtilityTool;

public class Player extends Entity {

	GamePanel gp;
	KeyHandler keyH;
	
	public final int screenX;
	public final int screenY;
	public int hasKey = 0;

	public Player(GamePanel gp, KeyHandler keyH) {

		this.gp = gp;
		this.keyH = keyH;
		
		screenX = gp.screenWidth/2 - (gp.tileSize/2);
		screenY = gp.screenHeight/2 - (gp.tileSize/2);
		
		
		// Player Hit Box
		solidArea = new Rectangle();
		solidArea.x = 10;
		solidArea.y = 20;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.y;
		solidArea.width = gp.tileSize - 20;
		solidArea.height = gp.tileSize - 10;

		setDefaults();
		getPlayerImage();

	}

	public void getPlayerImage() {
		
		up1 = setup("boy_up_1");
		up2 = setup("boy_up_2");
		down1 = setup("boy_down_1");
		down2 = setup("boy_down_2");
		left1 = setup("boy_left_1");
		left2 = setup("boy_left_2");
		right1 = setup("boy_right_1");
		right2 = setup("boy_right_2");

	}

	public BufferedImage setup(String imageName) {
		
		UtilityTool uTool = new UtilityTool();
		BufferedImage image = null;
		
		try {
			
			image = ImageIO.read(getClass().getResourceAsStream("/player/" + imageName + ".png"));
			image = uTool.ScaleImages(image, gp.tileSize, gp.tileSize);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return image;
	}
	public void setDefaults() {

		worldX = gp.tileSize * 23;
		worldY = gp.tileSize * 21;
		speed = 4;
		direction = "down";

	}

	public void update() {

		// if (keyH.upPressed == true ^  keyH.downPressed == true ^  keyH.leftPressed == true ^  keyH.rightPressed == true) { 
		if (keyH.upPressed == true || keyH.downPressed == true || keyH.leftPressed == true || keyH.rightPressed == true) {

			if (keyH.upPressed == true) {
				direction = "up";
			}

			if (keyH.downPressed == true) {
				direction = "down";

			}

			if (keyH.leftPressed == true) {
				direction = "left";

			}

			if (keyH.rightPressed == true) {
				direction = "right";

				// System.out.println("Moved");

			}
			
			// check player collision
			collisionOn = false;
			gp.cChecker.checkTile(this);
			
			// check object collision
			
			int objIndex = gp.cChecker.checkObject(this, true);
			pickUpObject(objIndex);
			
			// If collision is false, player can move
			
			if(collisionOn == false) {
				if(direction == "up") {
					worldY -= speed;
				} else if(direction == "down") {
					worldY += speed;
				}else if(direction == "left") {
					worldX -= speed;
				}else if(direction == "right") {
					worldX += speed;
				}
			}
			
			spriteCounter++;
			if (spriteCounter > 12) {
				if (spriteNum == 1) {
					spriteNum = 2;
				} else if (spriteNum == 2) {
					spriteNum = 1;
				}
				spriteCounter = 0;
			}
		}

	}
	
	
	// This is where all the pickup logic happens
	
	public void pickUpObject(int i) {
		
		if(i!= 999) {
			
			String objectName = gp.obj[i].name;
			
			if(objectName == "Key") {
				gp.playSoundEffect(1);
				hasKey++;
				gp.obj[i] = null;
				gp.ui.showMessage("You got a key!");
			}
			if(objectName == "Door") {
				if(hasKey > 0) {
					gp.playSoundEffect(3);
					gp.obj[i] = null;
					hasKey--;
					gp.ui.showMessage("You opened the door!");
				}else {
					gp.ui.showMessage("You need a key!");
				}
			}
			if(objectName == "Boots") {
				gp.playSoundEffect(2);
				speed += 2;
				gp.obj[i] = null;
				gp.ui.showMessage("Your speed has been enchanced!");
			}
			if(objectName == "Chest") {
				gp.stopMusic();
				gp.playSoundEffect(4);
				gp.ui.gameFinished = true;
			}
			

		}
		
	}

	public void draw(Graphics2D g2) {

//		g2.setColor(Color.white);
//		g2.fillRect(x, y, gp.tileSize, gp.tileSize);

		BufferedImage image = null;
		if (direction == "up") {
			if (spriteNum == 1) {
				image = up1;
			}
			if (spriteNum == 2) {
				image = up2;
			}
		}
		if (direction == "down") {
			if (spriteNum == 1) {
				image = down1;
			}
			if (spriteNum == 2) {
				image = down2;
			}
		}
		if (direction == "left") {
			if (spriteNum == 1) {
				image = left1;
			}
			if (spriteNum == 2) {
				image = left2;
			}
		}
		if (direction == "right") {
			if (spriteNum == 1) {
				image = right1;
			}
			if (spriteNum == 2) {
				image = right2;
			}
		}
		g2.drawImage(image, screenX, screenY, null);

	}
}
